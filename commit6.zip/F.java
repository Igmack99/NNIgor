public class F implements D {

    private double d = 100.500;

    private String g = "hello";

    public float ff() {
        return 3.14;
    }

    public int cc() {
        return 42;
    }

    public double ee() {
        return 500.100;
    }

    public void bb() {
        System.out.println(42);
    }
}
