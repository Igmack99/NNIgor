public class E extends null {

    private byte h = 1;

    private String b = "hello";

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public String kk() {
        return "Yes";
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public void ab() {
        System.out.println("\n");
    }

    public java.lang.Class qq() {
        return getClass();
    }

    public int cc() {
        return 13;
    }

    public long ac() {
        return 222;
    }
}
