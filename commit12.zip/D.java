public class D extends null {

    double ee();

    void bb();
}
