public class A extends F {

    private double c = 100.500;

    private byte h = 1;

    public Object rr() {
        return null;
    }

    public double ad() {
        return 9.11;
    }

    public int ae() {
        return 8;
    }

    public byte oo() {
        return 1;
    }
}
