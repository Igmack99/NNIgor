public class E {

    private byte h = 1;

    private String b = "hello";

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public String kk() {
        return "Yes";
    }
}
