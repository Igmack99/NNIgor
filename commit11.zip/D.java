public interface D {

    double ee();

    void bb();
}
