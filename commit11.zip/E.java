public class E {

    private byte h = 1;

    private String b = "hello";

    public int[] ii() {
        return new int[]{0, 1, 2, 3, 4};
    }

    public String kk() {
        return "Yes";
    }

    public void bb() {
        System.out.println(getClass().getName());
    }

    public double ee() {
        return java.lang.Math.PI;
    }

    public void ab() {
        System.out.println("\n");
    }

    public int cc() {
        return 39;
    }
}
